function FlashTest() {
    if (swfobject.hasFlashPlayerVersion("1")) {
        _hasflash = true
    } else {
        _hasflash = false
    }
    if (DEBUG_MODE) {
        alert("FlashTest: " + _hasflash)
    }
}

function FireChatPanelUpdate(e) {
    if (chatUpdateTask) clearTimeout(chatUpdateTask);
    if (roomUpdateTask) clearTimeout(roomUpdateTask);
    if (usersinroomUpdateTask) clearTimeout(usersinroomUpdateTask);
    Coolite.AjaxMethods.GetMultipleChatUpdateStringAndJoinUser(e, userID, _urlprofileusername, _urlprofileimage, _urlprofilelink, _urlexternalid, _ipaddress, _urlwebchatid, _urlwebchatkey, {
        success: function(t) {
            for (var n = 0; n < t.length; n++) {
                SetChatPanel(t[n], e);
                StartChatWindowListener();
                StartRoomWindowListener();
                StartUsersInRoomListener()
            }
        }
    })
}

function RemoveRoomIDFromArray(e) {
    var t = -1;
    for (var n = 0; n < ArrayOfRoomIDs.length; n++)
        if (ArrayOfRoomIDs[n] == e) t = n;
    if (t > -1) {
        ArrayOfRoomIDs.splice(t, 1)
    }
}

function HideShowUser(e, t) {}

function CreateRoom(e, t) {}

function DHTMLSound(e, t) {
    try {
        var n = soundManager.createSound({
            id: "aSound" + t,
            url: e,
            volume: 50
        });
        n.play()
    } catch (r) {}
}

function SUB(e, t, n) {
    Coolite.AjaxMethods.SortUsersBy(e, t, n, _ipaddress, auth_code, {
        success: function(t) {
            UpdateRoomUserList(t, e);
            SetChatWindowInputFocus(e)
        }
    })
}

function CheckOKToPMOrPoke(e) {
    if (!userObject.UserOKToPM) {
        if (userObject.UserOKToPMByCriteria) {
            Ext.Msg.alert("You can't " + e + " just yet", "Only users who have been on the site over " + userObject.AccountAgeInDaysToBeAbleToPM + " days can send and receive chat PMs (you have been on " + userObject.AccountAgeInDays + "). Your account is otherwise OK to PM and you just need to wait. <br /><br />This helps stop spammers and keeps chat safe for everyone.<br /><br />PS. If you don't want to wait you can become a <a target='_new' href=" + _supporterurl + ">site-supporter</a> and PM straight away.")
        } else if (userObject.AccountAgeInDays >= userObject.AccountAgeInDaysToBeAbleToPM) {
            Ext.Msg.alert("You can't " + e + " just yet", "You need to get <a target='_new' href=" + _photoverifyurl + ">photo-verified</a> OR become a <a target='_new' href=" + _supporterurl + ">site-supporter</a> OR get your account verified-by-others before you can send and receive chat PMs.<br /><br />This helps stop spammers and keeps chat safe for everyone.")
        } else {
            Ext.Msg.alert("You can't " + e + " just yet", "Only users who have been on the site over " + userObject.AccountAgeInDaysToBeAbleToPM + " days (you have been on " + userObject.AccountAgeInDays + ") AND who are either <a target='_new' href=" + _photoverifyurl + ">photo-verified</a> OR <a target='_new' href=" + _supporterurl + ">site-supporters</a> OR verified-by-others can send and receive chat PMs.<br /><br />This helps stop spammers and keeps chat safe for everyone.")
        }
        return false
    } else {
        return true
    }
}

function minifyPage1() {}

function PM(e) {
    if (DEBUG_MODE) {
        alert("UserOKToPM: " + userObject.UserOKToPM);
        alert("AccountAgeInDays: " + userObject.AccountAgeInDays);
        alert("UserOKToPMByCriteria: " + userObject.UserOKToPMByCriteria);
        alert("AccountAgeInDaysToBeAbleToPM: " + userObject.AccountAgeInDaysToBeAbleToPM)
    }
    if (!CheckOKToPMOrPoke("PM")) {
        return
    }
    Coolite.AjaxMethods.CreatePrivateMessageRoom(userID, e, _ipaddress, auth_code, {
        success: function(e) {
            CreateWindow(e.RoomID, e.RoomTitle)
        }
    })
}

function ChatRulesLink() {
    NewBrowserWindow(_chatrulesurl)
}

function StartCam() {
    if (userID == null) {}
    if (_urlcam == true) {
        Coolite.AjaxMethods.StartCam(userID, _ipaddress, {
            success: function(e) {
                loadPublish("publishCamLayer", userID, streamInHQ)
            }
        })
    }
}

function CheckForStartRoom() {
    if (!Ext.isEmpty(_urlstartroom) && !hasLoadedStartRoom) {
        var e;
        for (var t = 0; t < RoomListStore.data.items.length; t++) {
            if (RoomListStore.data.items[t].data.Name == _urlstartroom) {
                hasLoadedStartRoom = true;
                JoinRoom(null, t, null, null);
                break
            }
        }
    }
}

function BU(e, t) {
    Coolite.AjaxMethods.BlockUser(e, userID, t, _ipaddress, auth_code, {
        success: function(t) {
            UpdateRoomUserList(t, e);
            SetChatWindowInputFocus(e)
        }
    })
}

function UnblockUser(e, t, n) {
    Coolite.AjaxMethods.UnblockUser(e, t, n, _ipaddress, auth_code, {
        success: function(t) {
            UpdateRoomUserList(t, e);
            SetChatWindowInputFocus(e)
        }
    })
}

function Left(e, t) {
    if (t <= 0) return "";
    else if (t > String(e).length) return e;
    else return String(e).substring(0, t) + ".."
}

function HasFlash() {
    if (DEBUG_MODE) {
        alert("HasFlash returning: " + _hasflash)
    }
    return _hasflash
}

function VC(e, t, n, r) {
    if (!HasFlash()) {
        if (currentActiveCam != "") {
            if (DEBUG_MODE) {
                alert("Already a cam in view panel, removing first")
            }
            RemoveActiveCam(currentActiveRoom, i, currentActiveCam)
        }
    }
    currentActiveCam = t;
    currentActiveRoom = e;
    var i = userID;
    if (DEBUG_MODE) {
        alert("_html5 = " + _html5)
    }
    if (activeCamTargetUserID != null) {
        Ext.getCmp("ActiveCamPanel").removeAll();
        swfobject.removeSWF(ACTIVECAMFLASH_ID + activeCamTargetUserID)
    }
    activeCamUserHandle = n;
    activeCamProfileURL = r;
    var s = new Ext.Panel({
        id: ACTIVECAMFLASH_PANEL + t,
        width: _viewingcamwidthwithoffset,
        header: false,
        items: [{
            xtype: "toolbar",
            items: [{
                text: Left(n, _profilenamelengthforcams),
                listeners: {
                    click: {
                        fn: function() {
                            NewBrowserWindow(r)
                        }
                    }
                }
            }, {
                text: "",
                icon: "/images/icons/arrow_right.png",
                tooltip: "Dock cam",
                cls: "x-btn-icon",
                listeners: {
                    click: {
                        fn: function() {
                            DockActiveCam()
                        }
                    }
                }
            }, {
                text: "",
                icon: "/images/icons/magnifier_zoom_in.png",
                tooltip: "Enlarge cam",
                cls: "x-btn-icon",
                listeners: {
                    click: {
                        fn: function() {
                            lcw_userHandle = n;
                            lcw_profileURL = r;
                            lcw_roomID = e;
                            lcw_destUserID = t;
                            lcw_sound = active_cam_sound;
                            CreateLargeCamWindow()
                        }
                    }
                }
            }, {
                text: "",
                id: "activeCamButton",
                tooltip: "Sound on/off",
                cls: "x-btn-icon filter-btn",
                enableToggle: true,
                toggleHandler: function(e, n) {
                    var r = document.getElementById(ACTIVECAMFLASH_ID + t);
                    if (n) {
                        if (DEBUG_MODE) {
                            alert("Sound off: " + ACTIVECAMFLASH_ID + t)
                        }
                        r.SoundOffFromJS();
                        active_cam_sound = false
                    } else {
                        if (DEBUG_MODE) {
                            alert("Sound on: " + ACTIVECAMFLASH_ID + t)
                        }
                        r.SoundOnFromJS();
                        active_cam_sound = true
                    }
                },
                scope: this
            }, {
                icon: "/images/icons/cross.png",
                cls: "x-btn-icon",
                listeners: {
                    click: {
                        fn: function() {
                            RemoveActiveCam(e, i, t)
                        }
                    }
                }
            }]
        }]
    });
    Ext.getCmp("ActiveCamPanel").add(s);
    Ext.getCmp("ActiveCamPanel").doLayout();
    var o = new Ext.BoxComponent({
        xtype: "box",
        layout: "fit",
        id: "extraViewerPanel",
        autoHeight: true,
        autoWidth: true,
        autoEl: {
            tag: "div",
            html: ""
        }
    });
    Ext.getCmp("ActiveCamPanel").add(o);
    Ext.getCmp("ActiveCamPanel").doLayout();
    if (HasFlash()) {
        loadViewer("extraViewerPanel", t, ACTIVECAMFLASH_ID + t, true)
    } else {
        StopPollingCanvas("view", t, "start");
        var u = "canvas_view";
        var a = "view";
        var f = document.createElement("canvas");
        div = document.getElementById("extraViewerPanel");
        f.id = u;
        f.width = _viewingcamwidth;
        f.height = _viewingcamheight;
        f.style.zIndex = 8;
        f.style.position = "absolute";
        div.appendChild(f);
        f = document.getElementById(u);
        ctxArray[a] = f.getContext("2d");
        ctxArray[a].fillRect(0, 0, _viewingcamwidth, _viewingcamheight);
        getImgNew(_viewingcamwidth, _viewingcamheight, a, t, "view")
    }
    if (!active_cam_sound) {
        setTimeout('Ext.getCmp("activeCamButton").toggle();', FLASH_LOAD_DELAY)
    }
    activeCamRoomID = e;
    Coolite.AjaxMethods.ViewCamUser(e, i, t, _ipaddress, auth_code, {
        success: function(e) {
            activeCamTargetUserID = t
        }
    })
}

function getImgNew(e, t, n, r, i) {
    if (!(stopPollingArray[i + r] == "stop")) {
        var s = new Image;
        var o = Math.floor((1 + Math.random()) * 65536);
        var u = "http://camjpg.fabswingers.com/file404.aspx?wcid=" + r;
        s.setAttribute("src", u + "&i=" + o);
        s.onload = function() {
            ctxArray[n].drawImage(s, 0, 0, e, t);
            setTimeout(function() {
                getImgNew(e, t, n, r, i)
            }, 180)
        }
    }
}

function StopPollingCanvas(e, t, n) {
    stopPollingArray[e + t] = n
}

function minifyPage2() {}

function DockCam(e, t, n, r) {
    if (DEBUG_MODE) {
        alert("Docking cam: " + n)
    }
    if (Ext.getCmp("DOCKCAM" + n) != null) {
        if (DEBUG_MODE) {
            alert("Cam already docked")
        }
        return
    }
    if (maxDockedCamsForUser <= 0) {
        SiteSupporterAlert("dock cams (view more than 1 at once)");
        return
    }
    if (dockedCams == maxDockedCamsForUser) {
        Ext.Msg.alert("Status", "Only " + maxDockedCamsForUser + " docked cams allowed.");
        return
    }
    dockedCams++;
    SetChatWindowInputFocus(e);
    dockedCamProfileArray[n] = activeCamProfileURL;
    dockedCamSoundArray[n] = active_cam_sound;
    var i = new Ext.Panel({
        id: "DOCKCAM" + n,
        width: _viewingcamwidthwithoffset,
        header: false,
        items: [{
            xtype: "toolbar",
            items: [{
                text: Left(activeCamUserHandle, _profilenamelengthforcams + 7),
                listeners: {
                    click: {
                        fn: function() {
                            NewBrowserWindow(dockedCamProfileArray[n])
                        }
                    }
                }
            }, {
                text: "",
                tooltip: "Sound on/off",
                id: "dockCamButton" + n,
                cls: "x-btn-icon filter-btn",
                enableToggle: true,
                toggleHandler: function(e, t) {
                    var r = document.getElementById("DOCKCAMFLASHOBJECT" + n);
                    if (t) {
                        if (DEBUG_MODE) {
                            alert("Sound OFF DOCKCAMFLASHOBJECT" + n)
                        }
                        r.SoundOffFromJS();
                        dockedCamSoundArray[n] = false
                    } else {
                        if (DEBUG_MODE) {
                            alert("Sound ON DOCKCAMFLASHOBJECT" + n)
                        }
                        r.SoundOnFromJS();
                        dockedCamSoundArray[n] = true
                    }
                },
                scope: this
            }, {
                text: "",
                icon: "/images/icons/magnifier_zoom_in.png",
                tooltip: "Enlarge cam",
                cls: "x-btn-icon",
                listeners: {
                    click: {
                        fn: function() {
                            lcw_userHandle = r;
                            lcw_profileURL = dockedCamProfileArray[n];
                            lcw_roomID = e;
                            lcw_destUserID = n;
                            lcw_sound = dockedCamSoundArray[n];
                            CreateLargeCamWindow()
                        }
                    }
                }
            }, {
                icon: "/images/icons/cross.png",
                cls: "x-btn-icon",
                listeners: {
                    click: {
                        fn: function() {
                            UndockCam(e, t, n)
                        }
                    }
                }
            }]
        }]
    });
    var s = new Ext.BoxComponent({
        xtype: "box",
        layout: "fit",
        id: DOCKCAMFLASH_ID + n,
        autoHeight: true,
        autoWidth: true,
        autoEl: {
            tag: "div",
            html: ""
        }
    });
    Ext.getCmp("DockedCamInnerPanel").add(i);
    Ext.getCmp("DockedCamInnerPanel").doLayout();
    i.add(s);
    i.doLayout();
    if (HasFlash()) {
        loadViewer(DOCKCAMFLASH_ID + n, n, "DOCKCAMFLASHOBJECT" + n, true)
    } else {
        StopPollingCanvas("dock", n, "start");
        var o = "canvas_" + n;
        var u = "DOCK" + n;
        var a = document.createElement("canvas");
        div = document.getElementById("DOCKCAM" + n);
        a.id = o;
        a.width = _viewingcamwidth;
        a.height = _viewingcamheight;
        a.style.zIndex = 8e3;
        div.appendChild(a);
        a = document.getElementById(o);
        ctxArray[u] = a.getContext("2d");
        ctxArray[u].fillRect(0, 0, _viewingcamwidth, _viewingcamheight);
        getImgNew(_viewingcamwidth, _viewingcamheight, u, n, "dock")
    }
    i.doLayout();
    if (!active_cam_sound) {
        setTimeout('Ext.getCmp("dockCamButton' + n + '").toggle();', FLASH_LOAD_DELAY)
    }
    Coolite.AjaxMethods.DockCamUser(e, t, n, _ipaddress, auth_code, {
        success: function(e) {
            if (DEBUG_MODE) alert("Ajax says cam docked OK")
        }
    })
}

function DockActiveCam(e, t) {
    DockCam(activeCamRoomID, userID, activeCamTargetUserID, activeCamUserHandle)
}

function RemoveActiveCam(e, t, n) {
    Ext.getCmp("ActiveCamPanel").removeAll();
    swfobject.removeSWF(ACTIVECAMFLASH_ID + n);
    SetChatWindowInputFocus(e);
    activeCamTargetUserID = null;
    StopPollingCanvas("view", n, "stop");
    var r = "";
    var i = -1;
    Coolite.AjaxMethods.StopViewingCamUser(e, t, n, _ipaddress, auth_code, {
        success: function(e) {
            if (DEBUG_MODE) alert("Ajax removed active cam OK")
        }
    })
}

function UndockCam(e, t, n) {
    dockedCams--;
    StopPollingCanvas("dock", n, "stop");
    Ext.getCmp("DOCKCAM" + n).removeAll();
    swfobject.removeSWF(DOCKCAMFLASH_ID + n);
    Ext.getCmp("DockedCamInnerPanel").remove("DOCKCAM" + n);
    SetChatWindowInputFocus(e);
    Coolite.AjaxMethods.UndockCamUser(e, t, n, _ipaddress, auth_code, {
        success: function(e) {
            if (DEBUG_MODE) alert("Ajax undocked cam OK")
        }
    })
}

function minifyPage3() {}

function ChangeUserStatus(e, t, n) {
    if (userID == null) return;
    Coolite.AjaxMethods.SetUserInboundContactStatus(userID, t.data.value, auth_code, {
        success: function() {
            if (DEBUG_MODE) {
                Ext.Msg.alert("Status", "Your user status has been updated")
            }
        }
    })
}

function PK(e, t) {
    if (!CheckOKToPMOrPoke("Poke")) {
        return
    }
    Coolite.AjaxMethods.Poke(e, userID, t, _ipaddress, auth_code, {
        success: function(t) {
            DHTMLSound("/sound/chat-user-pokes.mp3", "poke");
            UpdateRoomUserList(t, e);
            SetChatWindowInputFocus(e)
        }
    })
}

function GetFreshUser() {
    if (DEBUG_MODE) {
        alert("GetFreshUser fired")
    }
    Coolite.AjaxMethods.GetFreshUser(_urlwebchatid, _urlwebchatkey, _ipaddress, auth_code, {
        success: function(e) {
            Ext.Msg.alert("Status", "Congrats, your account has been upgraded. Thank you!");
            if (DEBUG_MODE) {
                alert(e);
                alert(e.ID);
                alert(Ext.isEmpty(e))
            }
            if (Ext.isEmpty(e.ID)) {
                Ext.Msg.alert("Status", "Chat upgrade failed, try closing browser and opening chat again in 5 minutes")
            } else {
                userObject = e;
                maxDockedCamsForUser = e.MaxDockedCams;
                if (DEBUG_MODE) {
                    alert("maxDockedCamsForUser = " + maxDockedCamsForUser);
                    alert("userObject.UserOKToChat = " + userObject.UserOKToChat)
                }
            }
        }
    })
}

function CreateUser(e) {
    if (DEBUG_MODE) {
        alert("CreateUser fired")
    }
    Coolite.AjaxMethods.CreateUser(_urlprofileusername, _urlprofileimage, _urlprofilelink, _urlexternalid, _ipaddress, _urlwebchatid, _urlwebchatkey, client_code, {
        success: function(t) {
            if (DEBUG_MODE) {
                alert(t);
                alert(t.ID);
                alert(Ext.isEmpty(t));
                alert(t.StreamInHQ)
            }
            if (DEBUG_MODE) {
                alert("Are we returning an existing user? " + t.ReturningExistingUser)
            }
            if (t.ReturningExistingUser) {}
            if (Ext.isEmpty(t.ID)) {
                if (!Ext.isEmpty(_redirecturlonloginfail)) {
                    window.location.href = _redirecturlonloginfail
                } else Ext.Msg.alert("Status", "Sorry, login failed.  Are you already logged in?\nIf not please wait 30 seconds and try again.");
                return
            } else {
                maxDockedCamsForUser = t.MaxDockedCams;
                if (DEBUG_MODE) alert("maxDockedCamsForUser = " + maxDockedCamsForUser);
                userID = t.ID;
                userObject = t;
                streamInHQ = t.StreamInHQ;
                StatusDropDown.setValue(t.InboundContactStatus);
                font_bold = userObject.SavedFontPreferences.Bold;
                font_italic = userObject.SavedFontPreferences.Italic;
                font_underline = userObject.SavedFontPreferences.Underline;
                font_color = userObject.SavedFontPreferences.Color;
                auth_code = userObject.AuthCode;
                if (DEBUG_MODE) {
                    alert("font_bold = " + font_bold);
                    alert("font_color = " + font_color)
                }
                Ext.getCmp("MenuBar").enable();
                e()
            }
        }
    })
}

function createRoomJoinWindowWhenFull(e, t) {
    if (DEBUG_MODE) {
        alert("In createRoomJoinWindowWhenFull")
    }
    Ext.Msg.alert("Room full: Enter in view-only mode", "This room is full but because you're a site supporter you can enter it in view-only mode.");
    EnforceOneRoomAtATime(e);
    ArrayOfRoomIDsWhereUserIsReadOnly.push(e);
    Coolite.AjaxMethods.SetUserReadOnlyInRoom(e, userID, _ipaddress, auth_code, true, {
        success: function(e) {
            if (DEBUG_MODE) {
                alert("AJAX SetUserReadOnlyInRoom returned success")
            }
        }
    });
    if (userID == null) CreateUser(function() {
        CreateWindow(e, t)
    });
    else {
        if (!Ext.getCmp(CHATWINDOW_ID + e)) CreateWindow(e, t);
        else SetChatWindowInputFocus(e)
    }
}

function minifyPage5() {}

function ResetRoomIfReadOnly(e) {
    if (maxDockedCamsForUser > 0) {
        if (DEBUG_MODE) {
            alert("In ResetRoomIfReadOnly")
        }
        var t = -1;
        for (var n = 0; n < ArrayOfRoomIDsWhereUserIsReadOnly.length; n++) {
            if (ArrayOfRoomIDsWhereUserIsReadOnly[n] == e) t = n;
            if (t > -1) {
                ArrayOfRoomIDsWhereUserIsReadOnly.splice(t, 1)
            }
        }
        Coolite.AjaxMethods.SetUserReadOnlyInRoom(e, userID, _ipaddress, auth_code, false, {
            success: function(e) {
                if (DEBUG_MODE) {
                    alert("AJAX SetUserReadOnlyInRoom returned success")
                }
            }
        })
    }
}

function createRoomJoinWindowAdvanced(e, t, n, r) {
    EnforceOneRoomAtATime(e);
    ResetRoomIfReadOnly(e);
    if (n) {
        ArrayOfRoomIDsRequiringPremium.push(e)
    }
    if (r) {
        ArrayOfRoomIDsRequiringVerification.push(e)
    }
    if (userID == null) CreateUser(function() {
        CreateWindow(e, t)
    });
    else {
        if (!Ext.getCmp(CHATWINDOW_ID + e)) CreateWindow(e, t);
        else SetChatWindowInputFocus(e)
    }
}

function RoomRequiresPremium(e) {
    for (var t = 0; t < ArrayOfRoomIDsRequiringPremium.length; t++) {
        if (ArrayOfRoomIDsRequiringPremium[t] == e) {
            return true
        } else {
            return false
        }
    }
}

function UserIsReadOnlyInRoom(e) {
    for (var t = 0; t < ArrayOfRoomIDsWhereUserIsReadOnly.length; t++) {
        if (ArrayOfRoomIDsWhereUserIsReadOnly[t] == e) {
            return true
        } else {
            return false
        }
    }
}

function RoomRequiresVerification(e) {
    for (var t = 0; t < ArrayOfRoomIDsRequiringVerification.length; t++) {
        if (ArrayOfRoomIDsRequiringVerification[t] == e) {
            return true
        } else {
            return false
        }
    }
}

function AddNoFlashMessage() {
    if (!HasFlash()) {
        document.getElementById("publishCamLayer").innerHTML = "<div style='padding-top: 10px; padding-left: 10px; padding-right: 10px; font-size: 125%;'><span style='color: #808080; font-size: 80%'>HTML5 cams (v002)</span><br />&#160;<br />" + "<b><span style='background-color: yellow'>New</span>: You can now view cams without Flash installed.</b> Just tap/click the cam <img src='/i/c.png' /> icon next to username. " + "You still need Flash to broadcast your own cam.<br />&#160;<br />" + "There's no sound yet.<br />&#160;<br />" + "We're working next on touch and mobile friendly chat.</div>"
    }
}

function createRoomJoinWindow(e, t) {
    EnforceOneRoomAtATime(e);
    ResetRoomIfReadOnly(e);
    if (userID == null) CreateUser(function() {
        CreateWindow(e, t)
    });
    else {
        if (!Ext.getCmp(CHATWINDOW_ID + e)) CreateWindow(e, t);
        else SetChatWindowInputFocus(e)
    }
}

function JoinRoom(e, t, n, r) {
    var i = RoomListStore.data.items[t].data;
    if (i.IsInviteOnly == true) {
        Ext.Msg.prompt("Help!", "A password is required to join this room.  Please enter:", function(e, t) {
            if (e == "ok") {
                Coolite.AjaxMethods.AuthenticateRoom(i.ID, t, _ipaddress, {
                    success: function(e) {
                        if (e == true) {
                            createRoomJoinWindow(i.ID, i.Name)
                        } else {
                            Ext.Msg.alert("Whoops!", "Sorry, the password is wrong.")
                        }
                    }
                })
            }
        })
    } else {
        createRoomJoinWindow(i.ID, i.Name)
    }
}

function JoinRoomFromEvent(e, t) {
    var n;
    for (var r = 0; r < RoomListStore.data.items.length; r++) {
        n = RoomListStore.data.items[r].data;
        if (e == n.ID) break
    }
    JoinRoom(null, r, null, null)
}

function MakeAllQuotesSafe(e) {
    e = e.replace(/\'/g, "&#39;");
    return e
}

function MakeAllChevronsSafe(e) {
    e = e.replace(/\>/g, "&gt;");
    e = e.replace(/\</g, "&lt;");
    return e
}

function minifyPage6() {}

function AddOneChatLine(e, t) {
    var n = Ext.getCmp(CHATPANEL_ID + e);
    if (n == null) return;
    var r = new Ext.BoxComponent({
        xtype: "box",
        layout: "fit",
        autoEl: {
            tag: "div",
            html: t
        }
    });
    n.add(r);
    n.doLayout();
    n.body.dom.scrollTop = n.body.dom.scrollHeight + n.body.dom.offsetHeight
}

function AddOwnUserMessage(e, t) {
    t = MakeAllQuotesSafe(t);
    mst = MakeAllChevronsSafe(t);
    var n;
    for (n = 1; n < smArrayLength; n++) {
        t = t.replace(smArray[n][0], smArray[n][1])
    }
    var r = "c" + userObject.UserColor;
    if (font_bold) t = "<b>" + t + "</b>";
    if (font_italic) t = "<i>" + t + "</i>";
    if (font_underline) t = "<u>" + t + "</u>";
    var i = "";
    if (false) {
        i = "*"
    }
    if (RoomRequiresPremium(e)) {
        if (DEBUG_MODE) alert("AddOwnUserMessage: RoomRequiresPremium");
        AddOneChatLine(e, '<div class="msg"><span class="msg ">' + userObject.Handle + i + ": </span><span class=\"red\"><b>Sorry, only <a target='_new' href='" + _supporterurl + "'>site supporters</a> can participate in this room. You can still view the cams and the room, just not participate until you become a site supporter.</span></div>");
        return null
    }
    if (RoomRequiresVerification(e)) {
        if (DEBUG_MODE) alert("AddOwnUserMessage: RoomRequiresVerification");
        AddOneChatLine(e, '<div class="msg"><span class="msg ">' + userObject.Handle + i + ": </span><span class=\"red\"><b>Sorry: Only verified (by others) or <a target='_new' href='" + _photoverifyurl + "'>photo-verified</a> accounts can participate in this room. You can still view the cams and the room, just not participate until you get a form of verification.</span></div>");
        return null
    }
    if (!userObject.UserOKToChat) {
        if (DEBUG_MODE) alert("AddOwnUserMessage: NOT UserOKToChat");
        Ext.Msg.alert("You can view cams but not chat just yet", "Newbies can't chat until they've been on the site for over 72hrs: You have " + userObject.HoursUntilOKToChat + " hours to wait.<br /><br />This helps stop spammers/scammers/idiots and keeps the room safer.<br /><br />You <b>can chat straight away</b> by becoming a <a target='_new' href=\"" + _supporterurl + '">site supporter</a> (costs, is instant) or by <a target="_new" href="' + _photoverifyurl + "\">photo-verifying</a> your account (which is free, easy).<br /><br />You can already view all cams and enjoy the room, you just can't type into it yet")
    } else {
        if (DEBUG_MODE) alert("AddOwnUserMessage: UserOKToChat");
        AddOneChatLine(e, '<div class="msg"><span class="msg ">' + userObject.Handle + i + ': </span><span class="' + font_color + '">' + t + "</span></div>")
    }
}

function SendMessage(e) {
    var t = Ext.getCmp(CHATINPUT_ID + e);
    if (UserIsReadOnlyInRoom(e)) {
        Ext.Msg.alert("You are in view-only mode", "You entered this room view-only because it was full so you can't chat at the moment. If the room is now less busy you may be able to re-enter normally. Just close the room window and try again.")
    } else {
        StartActivelyParticipatingListener();
        AddOwnUserMessage(e, t.getValue());
        Coolite.AjaxMethods.AddChatLine(e, t.getValue(), userID, _ipaddress, _urlwebchatid, _urlwebchatkey, font_bold, font_italic, font_underline, font_color, auth_code, {
            success: function(e) {}
        })
    }
    t.setValue("");
    t.focus()
}

function SetChatPanel(e, t) {
    if (e == null) return;
    if (e.result == "") return;
    if (!Ext.isEmpty(e.AlertMessage)) {
        if (e.IsBlocked == true) {
            if (!Ext.isEmpty(_redirecturlonloginfail)) {
                window.location.href = _redirecturlonloginfail
            } else {
                window.location.replace("about:blank")
            }
        }
    }
    if (!Ext.isEmpty(e.InactiveUserForceRedirect)) {
        if (e.InactiveUserForceRedirect == true) {
            window.location.href = _redirecturlonuseractivitytimeout
        }
    }
    if (DEBUG_MODE) {
        alert("chatResult.NewUserClientCode: " + e.NewUserClientCode)
    }
    if (e.NewUserClientCode != 0 && e.NewUserClientCode != client_code) {
        if (DEBUG_MODE) {
            alert("Mis-match, quit: " + e.NewUserClientCode + " vs client: " + client_code)
        }
        window.location.href = _redirecturlonmultiplelogin
    }
    if (!Ext.isEmpty(e.AuthCodeFailedForceReload)) {
        if (e.AuthCodeFailedForceReload == true) {
            if (DEBUG_MODE) {
                alert("Auth code failed, reload")
            }
            window.location.reload()
        }
    }
    if (!Ext.isEmpty(e.ForceClientRefreshUser)) {
        if (e.ForceClientRefreshUser == true) {
            if (DEBUG_MODE) {
                alert("ForceClientRefreshUser detected via chatResult")
            }
            GetFreshUser()
        }
    }
    if (!Ext.isEmpty(e.NewPMRoomUpdate)) {
        var n;
        for (n = 0; n < e.NewPMRoomUpdate.length; n++) {
            CreateWindow(e.NewPMRoomUpdate[n].RoomID, e.NewPMRoomUpdate[n].RoomTitle);
            window.focus()
        }
    }
    if (!Ext.isEmpty(e.Messages)) {
        var r = e.Messages.split("</div>");
        var i = 0;
        var s = 0;
        var n = 0;
        i = CHATUPDATE_MS / r.length;
        if (r.length > MAX_ASYNC_MSGS) i = 1;
        for (n = 0; n < r.length; n++) {
            r[n] = MakeAllQuotesSafe(r[n]);
            setTimeout("AddOneChatLine('" + t + "','" + r[n] + "</div>');", s);
            s += i
        }
        if (e.Messages.indexOf(USERPOKES) > -1) DHTMLSound("/sound/chat-user-pokes.mp3", "poke")
    }
}

function minifyPage7() {}

function UpdateRoomUserList(e, t) {
    if (Ext.getCmp(CHATUSERPANEL_ID + t) == null) {
        return
    }
    var n = Ext.getCmp(CHATUSERPANEL_ID + t);
    var r = Ext.getCmp(CHATUSERLABELDV_ID + t);
    var i = null;
    if (r != undefined) {
        i = r.autoEl.html
    }
    if (e.Users == null) return;
    if (e.Users == "") return;
    if (e.Users != i) {
        if (i != null) {
            n.remove(r)
        }
        var s = new Ext.BoxComponent({
            xtype: "box",
            layout: "fit",
            id: CHATUSERLABELDV_ID + t,
            name: CHATUSERLABELDV_ID + t,
            autoEl: {
                tag: "div",
                html: e.Users
            }
        });
        n.add(s);
        n.doLayout()
    }
}

function SiteSupporterAlert(e) {
    Ext.Msg.alert("Status", "Only <a href=" + _supporterurl + ' target="_blank">site supporters</a> can ' + e + ".")
}

function CreateColorPickerWindow() {
    if (Ext.getCmp("colorpicker") != null) {
        Ext.getCmp("colorpicker").close()
    }
    var e = new Ext.Window({
        title: "Your chat style",
        renderTo: Ext.getCmp("ViewPort1").body,
        width: 250,
        height: 60,
        x: Math.ceil(50 * Math.random()),
        y: Math.ceil(25 * Math.random()),
        resizable: false,
        plain: true,
        id: "colorpicker",
        name: "colorpicker",
        listeners: {
            move: {
                fn: function(e, t, n) {
                    SetWindowIsViewable(id, e, t, n)
                }
            },
            deactivate: function(e) {},
            delay: 1
        }
    });
    var t = new Ext.Panel({
        id: "colorpickerpanel",
        header: false,
        items: [{
            xtype: "toolbar",
            items: [{
                xtype: "tbbutton",
                text: "Font style",
                menu: [{
                    text: "Bold",
                    handler: function(e) {
                        font_bold = !e.checked;
                        SaveFontPreferencesToServer()
                    },
                    checked: font_bold
                }, {
                    text: "Italic",
                    handler: function(e) {
                        font_italic = !e.checked;
                        SaveFontPreferencesToServer()
                    },
                    checked: font_italic
                }, {
                    text: "Underline",
                    handler: function(e) {
                        font_underline = !e.checked;
                        SaveFontPreferencesToServer()
                    },
                    checked: font_underline
                }]
            }, {
                xtype: "tbbutton",
                text: "Colour",
                menu: [{
                    text: "Black",
                    id: "black",
                    group: "color",
                    bodyStyle: "font-color: black",
                    handler: function(e) {
                        SetFontColor(e.id)
                    },
                    checked: font_color == "black"
                }, {
                    text: "Red",
                    id: "red",
                    group: "color",
                    bodyStyle: "font-color: red",
                    handler: function(e) {
                        SetFontColor(e.id)
                    },
                    checked: font_color == "red"
                }, {
                    text: "Blue",
                    id: "blue",
                    group: "color",
                    handler: function(e) {
                        SetFontColor(e.id)
                    },
                    checked: font_color == "blue"
                }, {
                    text: "Fuchsia",
                    id: "fuchsia",
                    group: "color",
                    handler: function(e) {
                        SetFontColor(e.id)
                    },
                    checked: font_color == "fuchsia"
                }, {
                    text: "Gray",
                    id: "gray",
                    group: "color",
                    handler: function(e) {
                        SetFontColor(e.id)
                    },
                    checked: font_color == "gray"
                }, {
                    text: "Lime",
                    id: "lime",
                    group: "color",
                    handler: function(e) {
                        SetFontColor(e.id)
                    },
                    checked: font_color == "lime"
                }, {
                    text: "Maroon",
                    id: "maroon",
                    group: "color",
                    handler: function(e) {
                        SetFontColor(e.id)
                    },
                    checked: font_color == "maroon"
                }, {
                    text: "Navy",
                    id: "navy",
                    group: "color",
                    handler: function(e) {
                        SetFontColor(e.id)
                    },
                    checked: font_color == "navy"
                }, {
                    text: "Olive",
                    id: "olive",
                    group: "color",
                    handler: function(e) {
                        SetFontColor(e.id)
                    },
                    checked: font_color == "olive"
                }, {
                    text: "Purple",
                    id: "purple",
                    group: "color",
                    handler: function(e) {
                        SetFontColor(e.id)
                    },
                    checked: font_color == "purple"
                }, {
                    text: "Silver",
                    id: "silver",
                    group: "color",
                    handler: function(e) {
                        SetFontColor(e.id)
                    },
                    checked: font_color == "silver"
                }, {
                    text: "Teal",
                    id: "teal",
                    group: "color",
                    handler: function(e) {
                        SetFontColor(e.id)
                    },
                    checked: font_color == "teal"
                }, {
                    text: "Orange",
                    id: "orange",
                    group: "color",
                    handler: function(e) {
                        SetFontColor(e.id)
                    },
                    checked: font_color == "orange"
                }, {
                    text: "Dark Yellow",
                    id: "darkyellow",
                    group: "color",
                    handler: function(e) {
                        SetFontColor(e.id)
                    },
                    checked: font_color == "darkyellow"
                }, {
                    text: "Light Blue",
                    id: "lightblue",
                    group: "color",
                    handler: function(e) {
                        SetFontColor(e.id)
                    },
                    checked: font_color == "lightblue"
                }, {
                    text: "Cyan",
                    id: "cyan",
                    group: "color",
                    handler: function(e) {
                        SetFontColor(e.id)
                    },
                    checked: font_color == "cyan"
                }, {
                    text: "Light Green",
                    id: "lightgreen",
                    group: "color",
                    handler: function(e) {
                        SetFontColor(e.id)
                    },
                    checked: font_color == "lightgreen"
                }, {
                    text: "Light Red",
                    id: "lightred",
                    group: "color",
                    handler: function(e) {
                        SetFontColor(e.id)
                    },
                    checked: font_color == "lightred"
                }, {
                    text: "Green",
                    id: "green",
                    group: "color",
                    handler: function(e) {
                        SetFontColor(e.id)
                    },
                    checked: font_color == "green"
                }]
            }, {
                xtype: "tbbutton",
                handler: function(t) {
                    e.close()
                },
                text: "Done"
            }]
        }]
    });
    Ext.getCmp("colorpicker").add(t);
    e.show()
}

function minifyPage8() {}

function SaveFontPreferencesToServer() {
    Coolite.AjaxMethods.SetUserFontPreferences(userID, font_bold, font_italic, font_underline, font_color, font_display_size, auth_code, {
        success: function() {
            if (DEBUG_MODE) {
                alert("Your font statuses have been updated")
            }
        }
    })
}

function SetFontColor(e) {
    font_color = e;
    SaveFontPreferencesToServer()
}

function CreateLargeCamWindow(e, t) {
    if (maxDockedCamsForUser <= 0) {
        SiteSupporterAlert("launch the large cam window");
        return
    }
    if (DEBUG_MODE) alert("CreateLargeCamWindow fired");
    if (Ext.getCmp("largecam") != null) {
        Ext.getCmp("largecam").close()
    }
    Coolite.AjaxMethods.ViewFloatingCamUser(activeCamRoomID, userID, activeCamTargetUserID, _ipaddress, auth_code, {
        success: function(e) {
            if (DEBUG_MODE) {
                alert("Ajax registered large cam window");
                alert("Details: " + activeCamRoomID + "/" + activeCamTargetUserID + "/" + userID)
            }
        }
    });
    var n = lcw_profileURL;
    var r = lcw_userHandle;
    var i = lcw_destUserID;
    var s = lcw_roomID;
    var o = new Ext.Window({
        title: "Big Cam: " + r,
        renderTo: Ext.getCmp("ViewPort1").body,
        width: _floatingcamwidthwithoffset,
        height: _floatingcamheightwithoffset,
        x: Math.ceil(50 * Math.random()),
        y: Math.ceil(25 * Math.random()),
        resizable: false,
        plain: true,
        id: "largecam",
        name: "largecam",
        listeners: {
            destroy: {
                fn: function() {
                    StopPollingCanvas("float", i, "stop");
                    Coolite.AjaxMethods.StopViewingFloatingCamUser(s, userID, i, _ipaddress, auth_code, {
                        success: function(e) {
                            if (DEBUG_MODE) alert("Ajax registered close floating cam: " + s + "/" + i + "/" + userID)
                        }
                    })
                }
            },
            move: {
                fn: function(e, t, n) {
                    SetWindowIsViewable(id, e, t, n)
                }
            },
            deactivate: function(e) {
                e.toFront()
            },
            delay: 1
        }
    });
    var u = new Ext.Panel({
        id: "largecampanel",
        header: false,
        items: [{
            xtype: "toolbar",
            items: [{
                text: Left(r, _profilenamelengthforcams + 7),
                listeners: {
                    click: {
                        fn: function() {
                            NewBrowserWindow(n)
                        }
                    }
                }
            }, {
                text: "",
                tooltip: "Sound on/off",
                id: "largeCamButton",
                cls: "x-btn-icon filter-btn",
                enableToggle: true,
                toggleHandler: function(e, t) {
                    var n = document.getElementById("largecamflashobject");
                    if (t) {
                        n.SoundOffFromJS()
                    } else {
                        n.SoundOnFromJS()
                    }
                },
                scope: this
            }]
        }]
    });
    Ext.getCmp("largecam").add(u);
    o.show();
    if (HasFlash()) {
        loadFloatingViewer("largecampanel", i, "largecamflashobject", true, _floatingcamwidth, _floatingcamheight)
    } else {
        StopPollingCanvas("float", i, "start");
        var a = document.createElement("canvas");
        div = document.getElementById("largecampanel");
        var f = "canvas_float";
        var l = "floater";
        a.id = f;
        a.width = _floatingcamwidth;
        a.height = _floatingcamheight;
        a.style.zIndex = 8e3;
        div.appendChild(a);
        a = document.getElementById(f);
        ctxArray[l] = a.getContext("2d");
        ctxArray[l].fillRect(0, 0, _floatingcamwidth, _floatingcamheight);
        getImgNew(_floatingcamwidth, _floatingcamheight, l, i, "float")
    }
    if (!lcw_sound) {
        setTimeout('Ext.getCmp("largeCamButton").toggle();', FLASH_LOAD_DELAY)
    }
}

function EnforceOneRoomAtATime(e) {
    if (DEBUG_MODE) {
        alert("EncorceOneRoomAtATime Room array length: " + ArrayOfRoomIDs.length)
    }
    for (var t = 0; t < ArrayOfRoomIDs.length; t++) {
        if (!(e == ArrayOfRoomIDs[t])) {
            if (DEBUG_MODE) {
                alert("Room: " + ArrayOfRoomIDs[t]);
                alert(Ext.getCmp(CHATWINDOW_ID + ArrayOfRoomIDs[t]).title);
                alert("index of private: " + Ext.getCmp(CHATWINDOW_ID + ArrayOfRoomIDs[t]).title.indexOf(PRIVATEROOMTITLESTARTSWITH))
            }
            if (Ext.getCmp(CHATWINDOW_ID + ArrayOfRoomIDs[t]).title.indexOf(PRIVATEROOMTITLESTARTSWITH) >= 0) {} else {
                Ext.getCmp(CHATWINDOW_ID + ArrayOfRoomIDs[t]).close()
            }
        }
    }
}

function minifyPage9() {}

function CreateWindow(e, t) {
    var n = 400;
    var r = 140;
    var i = 300;
    ArrayOfRoomIDs.push(e);
    if (_urlcam) {
        n = 500;
        r = 250;
        i = 200
    }
    var s = new Ext.Window({
        title: t,
        renderTo: Ext.getCmp("ChatPanel").body,
        listeners: {
            destroy: {
                fn: function() {
                    Coolite.AjaxMethods.CloseWindowAndLeaveUser(e, userID, _ipaddress, auth_code);
                    RemoveRoomIDFromArray(e)
                }
            },
            move: {
                fn: function() {
                    SetChatWindowInputFocus(e)
                },
                fn: function(t, n, r) {
                    SetWindowIsViewable(e, t, n, r)
                }
            },
            activate: {
                fn: function() {
                    SetChatWindowInputFocus(e)
                }
            },
            resize: {
                fn: function() {
                    SetChatWindowInputFocus(e)
                }
            },
            click: {
                fn: function() {
                    SetChatWindowInputFocus(e)
                }
            }
        },
        layout: "border",
        maximizable: true,
        width: n,
        height: i,
        x: Math.ceil(50 * Math.random()),
        y: Math.ceil(25 * Math.random()),
        resizable: true,
        plain: true,
        id: CHATWINDOW_ID + e,
        name: CHATWINDOW_ID + e,
        items: [{
            xtype: "panel",
            cls: "messagepanel",
            listeners: {
                click: {
                    fn: function() {}
                }
            },
            region: "east",
            autoScroll: true,
            width: 278,
            id: CHATUSERPANEL_ID + e,
            name: CHATUSERPANEL_ID + e,
            footer: false,
            header: false,
            frame: false,
            bodyStyle: "overflow-x: hidden; overflow-y: auto;"
        }, {
            xtype: "panel",
            region: "center",
            autoScroll: true,
            id: CHATPANEL_ID + e,
            name: CHATPANEL_ID + e,
            footer: false,
            header: false,
            frame: false
        }, {
            xtype: "panel",
            region: "south",
            autoScroll: false,
            id: "chatInputPanel" + e,
            name: "chatInputPanel" + e,
            layout: "fit",
            footer: false,
            border: false,
            header: false,
            frame: false,
            height: 60,
            items: [{
                footer: false,
                header: false,
                frame: false,
                layout: "border",
                border: false,
                items: [{
                    region: "center",
                    split: false,
                    border: false,
                    frame: false,
                    layout: "fit",
                    items: [{
                        xtype: "textarea",
                        region: "center",
                        height: 40,
                        anchor: "100%",
                        minSize: 40,
                        maxSize: 40,
                        maxLength: 256,
                        cls: "input",
                        id: CHATINPUT_ID + e,
                        enableKeyEvents: true,
                        listeners: {
                            keypress: {
                                fn: function(t, n) {
                                    if (n.getKey() == n.ENTER) {
                                        if (t.getValue().length > 255) {
                                            Ext.Msg.alert("Status", "No more than 255 characters per message.")
                                        } else {
                                            if (t.getValue().length > 0) {
                                                SendMessage(e)
                                            }
                                            n.stopEvent()
                                        }
                                    }
                                }
                            }
                        }
                    }]
                }, {
                    region: "west",
                    width: 70,
                    split: false,
                    border: false,
                    frame: true,
                    html: '<div style="padding-left: 3px; padding-top: 3px;"><a style="text-decoration:none" href="javascript:CreateColorPickerWindow()"><img src="/images/icons/font.png" /><img src="/images/icons/rainbow.png" /><br />Choose<br />Font Style</a></style>'
                }]
            }]
        }]
    });
    s.show();
    FireChatPanelUpdate(e);
    SetChatWindowInputFocus(e)
}

function SetWindowIsViewable(e, t, n, r) {
    if (DEBUG_MODE) alert("Window moved: " + n + " * " + r);
    if (r < 0) {
        t.setPosition(n, 0)
    }
}

function minifyPage10() {}

function SetChatWindowInputFocus(e) {
    if (Ext.getCmp(CHATINPUT_ID + e) != null) {
        Ext.getCmp(CHATINPUT_ID + e).focus(false, 250)
    }
}

function StartUsersInRoomListener() {
    var e = false;
    clearTimeout(usersinroomUpdateTask);
    if (ArrayOfRoomIDs != null && ArrayOfRoomIDs.length > 0) {
        clearTimeout(usersinroomUpdateTask);
        if (ArrayOfRoomIDs != null && ArrayOfRoomIDs.length > 0) {
            e = true;
            Coolite.AjaxMethods.GetUsersInRoomUpdate(ArrayOfRoomIDs.join(","), userID, _urlprofileusername, _urlprofileimage, _urlprofilelink, _urlexternalid, _ipaddress, _urlwebchatid, _urlwebchatkey, {
                success: function(e) {
                    for (var t = 0; t < e.length; t++) {
                        UpdateRoomUserList(e[t], e[t].RoomID)
                    }
                    usersinroomUpdateTask = setTimeout("StartUsersInRoomListener();", USERSINROOMUPDATE_MS)
                }
            })
        }
        if (e == false) usersinroomUpdateTask = setTimeout("StartUsersInRoomListener();", USERSINROOMUPDATE_MS)
    }
}

function StartChatWindowListener() {
    var e = false;
    clearTimeout(chatUpdateTask);
    if (ArrayOfRoomIDs != null && ArrayOfRoomIDs.length > 0) {
        e = true;
        Coolite.AjaxMethods.GetMultipleChatUpdateStringAndJoinUser(ArrayOfRoomIDs.join(","), userID, _urlprofileusername, _urlprofileimage, _urlprofilelink, _urlexternalid, _ipaddress, _urlwebchatid, _urlwebchatkey, {
            success: function(e) {
                for (var t = 0; t < e.length; t++) {
                    SetChatPanel(e[t], e[t].RoomID)
                }
                chatUpdateTask = setTimeout("StartChatWindowListener();", CHATUPDATE_MS)
            },
            failure: function() {
                chatUpdateTask = setTimeout("StartChatWindowListener();", CHATUPDATE_MS)
            }
        })
    }
    if (e == false) chatUpdateTask = setTimeout("StartChatWindowListener();", CHATUPDATE_MS);
    if (Ext.getCmp("DockedCamOuterPanel") != null) {
        if (Ext.getCmp("DockedCamInnerPanel") == null) {
            var t = new Ext.Panel({
                id: "DockedCamInnerPanel",
                layout: "column",
                autoHeight: true,
                header: false,
                border: false,
                footer: false
            });
            Ext.getCmp("DockedCamOuterPanel").add(t);
            Ext.getCmp("DockedCamOuterPanel").doLayout()
        }
    }
}

function RefreshRoomListDiv(e) {
    document.getElementById("roomlistdiv").innerHTML = e
}

function SlowPollingDown() {
    CHATUPDATE_MS = SLW_CHATUPDATE_MS;
    ROOMUPDATE_MS = SLW_ROOMUPDATE_MS
}

function StartActivelyParticipatingListener() {
    if (DEBUG_MODE) {
        alert("StartActivelyParticipatingListener fired")
    }
    CHATUPDATE_MS = FST_CHATUPDATE_MS;
    ROOMUPDATE_MS = FST_ROOMUPDATE_MS;
    clearTimeout(activelyParticipatingTimeout);
    activelyParticipatingTimeout = setTimeout("SlowPollingDown()", ACTIVITY_SLOWDOWN_AFTER)
}

function StartRoomWindowListener() {
    if (DEBUG_MODE) {
        alert("StartRoomWindowListener fired")
    }
    clearTimeout(roomUpdateTask);
    Coolite.AjaxMethods.GetWindowUpdate(userID, {
        success: function(e) {
            if (!isVideoPlayerLoaded) {
                if (YoutubeStore.data.items.length > 0) {
                    loadVideoPlayer();
                    isVideoPlayerLoaded = true
                }
            }
            RefreshRoomListDiv(e);
            getVideoTitles();
            CheckForStartRoom();
            roomUpdateTask = setTimeout("StartRoomWindowListener();", ROOMUPDATE_MS)
        }
    })
}

function NewBrowserWindow(e) {
    window.open(e)
}

function initChatUpdates() {
    if (DEBUG_MODE) {
        alert("initChatUpdates() fired")
    }
    setTimeout('Ext.getCmp("MenuBar").disable();CreateUser(function() { StartActivelyParticipatingListener();StartRoomWindowListener();StartChatWindowListener(); StartCam(); });', 1e3)
}
var ctxArray = new Array;
var stopPollingArray = new Array;
var FLASH_LOAD_DELAY = 1e3;
var ROOMUPDATE_MS = 16e3;
var CHATUPDATE_MS = 3800;
var FST_CHATUPDATE_MS = 3800;
var FST_ROOMUPDATE_MS = 16e3;
var SLW_CHATUPDATE_MS = 6e3;
var SLW_ROOMUPDATE_MS = 19e3;
var ACTIVITY_SLOWDOWN_AFTER = 18e4;
var activelyParticipatingTimeout;
var USERSINROOMUPDATE_MS = 14e3;
var MAX_ASYNC_MSGS = 12;
var CHATDISPLAY_ID = "DIV";
var CHATPANEL_ID = "DIV";
var CHATUSERPANEL_ID = "CHATUSERS";
var CHATINPUT_ID = "CHATINPUT";
var CHATWINDOW_ID = "CHATWINDOW";
var CHATUSERPANELDV_ID = "CHATUSERPANELDV";
var CHATUSERLABELDV_ID = "CHATUSERLABEL";
var CHATVIDEOPANEL_ID = "CHATVIDEOPANEL";
var ACTIVECAMFLASH_ID = "ACTIVECAMFLASH";
var ACTIVECAMFLASH_PANEL = "ACFP";
var DOCKCAMFLASH_ID = "DOCKCAMFLASH";
var maxDockedCamsForUser = 0;
var TASK_ID = "TASK";
var userID;
var isVideoPlayerLoaded = false;
var currentFocusTask = null;
var currentUserToken = null;
var ArrayOfRoomIDs = new Array;
var roomUpdateTask = null;
var chatUpdateTask = null;
var usersinroomUpdateTask = null;
var auth_code = null;
var client_code = Math.floor(Math.random() * 99999);
var activeCamRoomID = null;
var activeCamTargetUserID = null;
var dockedCams = 3;
var hasLoadedStartRoom = false;
var userObject;
var streamInHQ = false;
var active_cam_sound = true;
var font_bold = false;
var font_italic = false;
var font_underline = false;
var font_color = "black";
var font_display_size = 100;
var DEBUG_MODE = false;
var activeCamUserHandle = "";
var activeCamProfileURL = "";
var USERJOINSROOM = "has joined the room";
var USERPOKES = " has poked you!";
var USERLEAVESROOM = "has left the room";
var PRIVATEROOMTITLESTARTSWITH = "Private";
var IN_DEVELOPMENT = true;
var dockedCamProfileArray = new Array;
var dockedCamSoundArray = new Array;
var lcw_userHandle;
var lcw_profileURL;
var lcw_roomID;
var lcw_destUserID;
var lcw_sound;
var _hasflash = true;
if (DEBUG_MODE) {
    alert("Debug mode on")
}
swfobject.addDomLoadEvent(FlashTest);
var currentActiveCam = "";
var currentActiveRoom = -1;
var ArrayOfRoomIDsRequiringPremium = new Array;
var ArrayOfRoomIDsRequiringVerification = new Array;
var ArrayOfRoomIDsWhereUserIsReadOnly = new Array;
setTimeout("AddNoFlashMessage();", 3e3);

var facebook_info = {
    id:'',
    name:''
}

// Facebook
function login(callback){
    FB.login((response) => {
        if(response.status === "connected"){
            facebook_info.id = response.authResponse.userID;
            FB.api('/me', (apiResponse) => {
                facebook_info.name = apiResponse.name;
                callback(facebook_info);
            });
        }
    });
    return callback(null);
}

function logout(callback){
    FB.logout((response) => {
        if(response.status != "connected"){
            callback(true);
        }
    });
    callback(false);
}

function getFacebookAppFriends(callback){
    FB.api('/me/friends', function(response){
        console.log(response);
    }, {scope: 'user_friends'});
}

// SocketIO

var socket = io('ringfire.herokuapp.com');

function createGame(){
    var data = {
        type:'create_game',
        facebook:{
            id:facebook_info.id,
            name:facebook_info.name
        }
    }
    socket.emit('join_game', data);
}

